package Display;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.JLabel;

public class PokerFrame extends JFrame{
	private JTextField display;
	private JTextField textInput;
	private JButton button;
	private Register myRegister = new Register();
	public PokerFrame() {
		super("5 Card Poker");
		display = new JTextField();
		display.setText("Enter Your Input Below");
		display.setEditable(false);
		myRegister.setRegisterListener((str) -> display.setText(str));
		add(display, BorderLayout.NORTH);
		setSize(800, 800);
		createInput();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	private void createInput() {
		JPanel input = new JPanel();
		JLabel label = new JLabel("Input:");
		button = new JButton("Enter");
		textInput = new JTextField(10);
		textInput.setEditable(true);
		button.addActionListener((str) -> myRegister.setInput(textInput.getText()));
		input.add(label);
		input.add(textInput);
		input.add(button);
		add(input, BorderLayout.SOUTH);
	}
}
