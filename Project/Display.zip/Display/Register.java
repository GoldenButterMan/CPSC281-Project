package Display;

import java.util.function.Consumer;

public class Register {
	String output = "";
	private Consumer<String> sink;
	
	public Register() {
		setRegisterListener((s) -> {});
	}
	
	public void setRegisterListener(Consumer<String> input) {
		this.sink = input;
	}
	
	private void update() {
		sink.accept(getDisplayText());
	}
	
	public String getDisplayText() {
		if(output.toLowerCase().equals("draw")) {
			output = "You drew a card";
		}
		if(output.toLowerCase().equals("fold")) {
			output = "You fold your hand";
		}
		return output;
	}
	
	public void setInput(String in) {
		output = in;
		update();
	}

}
